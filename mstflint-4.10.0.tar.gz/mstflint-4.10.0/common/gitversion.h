#define TOOLS_GIT_SHA "a918b03"
